﻿
CREATE DATABASE IF NOT EXISTS `sara` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `sara`;


CREATE TABLE `aulas` (
  `aula` int UNSIGNED DEFAULT NULL,
  `estado` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `cursos` (
  `curso` text DEFAULT NULL,
  `profesor` text DEFAULT NULL,
  `dia` int UNSIGNED DEFAULT NULL,
  `mes` int UNSIGNED DEFAULT NULL,
  `anno` int UNSIGNED DEFAULT NULL,
  `hora` int UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `usuarios` (
  `usuario` text NOT NULL,
  `clave` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT INTO `usuarios` (`usuario`, `clave`) VALUES
('invitado', 1111),
('profesor', 2222),
('monitor', 3333),
('admin', 4444);
