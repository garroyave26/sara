<!DOCTYPE html>
<html>
<head>
	<title>Narrador</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link href='http://localhost/parcial2/css/main.css' rel='stylesheet'>
	<script src='http://localhost/parcial2/js/jquery.min.js'></script>
	<script src='http://localhost/parcial2/js/narrador.js'></script>
	<script src="//js.pusher.com/3.1/pusher.min.js"></script>
</head>
<body class="body">
	<h1 align="center" class="titulo">Copa América Centenario</h1>
	<br>
	<div align="center">
	<form id="formulario" >	
		<table align="center">
			<tr>
				<td>
					<input name="equipo1" type="text" class="input1"></input>
				</td>
				<td>
					<input name="marcador1" type="text" class="input2"></input>
				</td>
				<td>
					<input name="marcador2" type="text" class="input2"></input>
				</td>
				<td>
					<input name="equipo2" type="text" class="input1"></input>
				</td>
			</tr>
			</table>
			<br>
			<input id='idMensaje' name="mensaje" type="text" class="input3"></input>
			<br>
			<br>
			<tr>
				<td>
					<input id='idMinuto' name="minuto" type="text" class="input2"></input>
				</td>
				<td>
					<input id="IdEnviar" name="enviar" type="submit" value="Enviar" class="button"></input>
				</td>
			</tr>
		</table>
		<h2 align="center" class="narracion">NARRACIÓN</h2>
		<div align="center" id='contenedor' class="narracion1"></div>
		
	</form>
	</div>
	<br>
	<br>
	<div align="center">
		<form id='formulario1' action="http://localhost/parcial2/narrador/reiniciar" method="POST">
			<input align="center" id='IdReiniciar' type="submit" name="reiniciar" value="Reiniar"></input>
		</form>	
	</div>
	
</body>
</html>