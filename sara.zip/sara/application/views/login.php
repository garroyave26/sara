<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>SARA -</title>
</head>
<body>
    <div align="center">
	<h1>Sistema Administrador de Reservas de Aulas</h1>
    <form action="http://localhost/sara/loginSara/verificacionDatos" method="POST">
        Usuario:
        <input type="text" name="usuario">
        <br><br>
        Contraseña:
        <input type="password" name="contrasena">
        <br><br>
        <input type="submit" name="Ingresar" value="Ingresar">
    </form>
    </div>
</body>
</html>