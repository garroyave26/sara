<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<link href='http://localhost/sara/css/main.css' rel='stylesheet'>
	<script src="//js.pusher.com/3.1/pusher.min.js"></script>
	<script src='http://localhost/sara/js/jquery.min.js'></script>
	<script src='http://localhost/sara/js/sara.js'></script>
	<title>SARA -</title>
</head>
<body>
    <div align="center">
	<h1 id="prueba1">Sistema Administrador de Reservas de Aulas - Tiempo Real</h1>

	<br>
	<h2>Piso 1</h2>
	<table class="tabla">
		<tr>
			<td class="td3" id="prueba"><div id="id1" align="center">1.</div></td>
			<td class="td6"><div></div></td>
			<td class="td6"><div></div></td>
			<td class="td6"><div></div></td>
			<td class="td6"><div></div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id18td"><div id="id18" align="center">18.</div></td>
		</tr>
		<tr>
			<td class="td3" id="id3td"><div id="id3" align="center">3.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id2td"><div id="id2" align="center">2.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id17td"><div id="id17" align="center">17.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id16td"><div id="id16" align="center">16.</div></td>
		</tr>
		<tr>
			<td class="td3" id="id5td"><div id="id5" align="center">5.</div></td>
			<td class="td6"><div ></div></td>
			<td id="id4td" class="td3"><div id="id4" align="center">4.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id15td"><div id="id15" align="center">15.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id14td"><div id="id14" align="center">14.</div></td>
		</tr>
		<tr>
			<td class="td3" id="id7td"><div id="id7" align="center">7.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id6td"><div id="id6" align="center">6.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id13td"><div id="id13" align="center">13.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id12td"><div id="id12" align="center">12.</div></td>
		</tr>
		<tr>
			<td class="td3" id="id9td"><div id="id9" align="center">9.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id8td"><div id="id8" align="center">8.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id11td"><div id="id11" align="center">11.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id10td"><div id="id10" align="center">10.</div></td>
		</tr>					
	</table>
	<h2>Piso 2</h2>
	<table class="tabla">
		<tr>
			<td class="td3" id="id19td"><div id="id19" align="center">19.</div></td>
			<td class="td6"><div></div></td>
			<td class="td6" ><div></div></td>
			<td class="td6"><div></div></td>
			<td class="td6"><div></div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id36td"><div id="id36" align="center">36.</div></td>
		</tr>
		<tr>
			<td class="td3" id="id21td"><div id="id21" align="center">21.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id20td"><div id="id20" align="center">20.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id35td"><div id="id35" align="center">35.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id34td"><div id="id34" align="center">34.</div></td>
		</tr>
		<tr>
			<td class="td3" id="id23td"><div id="id23" align="center">23.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id22td"><div id="id22" align="center">22.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id33td"><div id="id33" align="center">33.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id32td"><div id="id32" align="center">32.</div></td>
		</tr>
		<tr>
			<td class="td3" id="id25td"><div id="id25" align="center">25.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id24td"><div id="id24" align="center">24.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id31td"><div id="id31" align="center">31.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id30td"><div id="id30" align="center">30.</div></td>
		</tr>
		<tr>
			<td class="td3" id="id27td"><div id="id27" align="center">27.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id26td"><div id="id26" align="center">26.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id29td"><div id="id29" align="center">29.</div></td>
			<td class="td6"><div></div></td>
			<td class="td3" id="id28td"><div id="id28" align="center">28.</div></td>
		</tr>					
	</table>
    
    </div>
</body>
</html>