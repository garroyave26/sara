<!DOCTYPE html>
<html>
<head>
	<title>Partidos</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link href='http://localhost/parcial2/css/main.css' rel='stylesheet'>
	<script src='http://localhost/parcial2/js/jquery.min.js'></script>
	<script src='http://localhost/parcial2/js/cliente.js'></script>
	<script src="//js.pusher.com/3.1/pusher.min.js"></script>
</head>
<body class="body">
	<h1 align="center" class="titulo">Copa América Centenario</h1>
	<br>
	<form id="formularioCliente" >	
		<table align="center" class="tabla">
			
			<tr> 
				<td>
					<?php
						if($equipos!==false){ 
							foreach ($equipos->result() as $equipo) { ?>
								<div id='equipo1' align="center" class='td'><?php echo $equipo->equipo1 ?></div>
							<?php }
						}else{ ?>	
							<div id='equipo1' align="center" class='td'></div>
							<?php } ?>		
				</td>
				<td>
					<?php
						if($equipos!==false){ 
							foreach ($equipos->result() as $equipo) { ?>
								<div id='marcador1' align="center" class='marcador'><?php echo $equipo->marcador1 ?></div>
							<?php }
						}else{ ?>	
							<div id='marcador1' align="center" class='marcador'></div>
							<?php } ?>
				</td>
				<td>
					<?php
						if($equipos!==false){ 
							foreach ($equipos->result() as $equipo) { ?>
								<div id='marcador2' align="center" class='marcador'><?php echo $equipo->marcador2 ?></div>
							<?php }
						}else{ ?>	
							<div id='marcador2' align="center" class='marcador'></div>
							<?php } ?>
				</td>
				<td>
					<?php
						if($equipos!==false){ 
							foreach ($equipos->result() as $equipo) { ?>
								<div id='equipo2' align="center" class='td'><?php echo $equipo->equipo2 ?></div>
							<?php }
						}else{ ?>	
							<div id='equipo2' align="center" class='td'></div>
							<?php } ?>
				</td>
			</tr>
			
		</table>
		<div align="center">
		<br><br>	
					<h2 align="center" class="narracion">NARRACION</h2>
					<?php
						if($narracion!==false){ 
							foreach ($narracion->result() as $mensaje) {
								echo '<div align="center" class="narracion1">'.$mensaje->minuto.'´          '.$mensaje->mensaje.'</div>';
							}
						}		
					?>	
					<div id='contenedor' align="center"></div>				
		</div>	
		
	</form>
</body>
</html>