<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link href='http://localhost/sara/css/main.css' rel='stylesheet'>
	<script src='http://localhost/sara/js/jquery.min.js'></script>
	<script src='http://localhost/sara/js/admin.js'></script>
	<script src="//js.pusher.com/3.1/pusher.min.js"></script>
	<title>SARA -</title>
</head>
<body>
    <div align="center">
	<h1>Administrador</h1>

	<form id="formulario">
		Numero de aula: <input type="text" name="aula"><br><br>
		Estado del aula: <select name="estado">
			<option>Ocupada</option>
			<option>Reservada</option>
			<option>Libre</option>
			<option>No disponible</option>
			<option>Alerta</option>
		</select><br><br>
		Nombre del Curso: <input type="text" name="curso"><br><br>
		Profesor: <input type="text" name="profesor"><br><br>
		Fecha:  <input type="text" name="dia">
				<input type="text" name="mes">
				<input type="text" name="anno"><br><br>
		Horario: <input type="text" name="hora"><br><br>
		<input id="idEnviar" type="submit" name="enviar">
	</form>
    
    </div>
</body>
</html>