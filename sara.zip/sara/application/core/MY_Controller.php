<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

	function __construct() 
	{
        parent::__construct();
        if($this->ion_auth->logged_in()===FALSE)
        {
            redirect('login');
        }
		
    }
  
    protected function render($view = NULL, $data=array(), $template = 'main')
    {
        if($view == 'json')
        {
            header('Content-Type: application/json');
            echo json_encode($data);
        }
        else
        {
            $data['content'] = (is_null($view)) ? '' : $this->load->view($view, $data, TRUE);
            $this->load->view('templates/' . $template , $data);
        }
    }
}
