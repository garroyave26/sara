<?php

class Cliente_model extends CI_Model{

	function __construct(){
		parent:: __construct();
		$this->load->database();
	}

	function recuperarDatos(){
		$query = $this->db->get('narracion');
		if ($query->num_rows()>0) {
			return $query;
		}else{
			return false;
		}
	}

	function recuperarEquipos(){
		$query = $this->db->get('equipos');
		if ($query->num_rows()>0) {
			return $query;
		}else{
			return false;
		}		
	}

}