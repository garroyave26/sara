<?php

class LoginSara_model extends CI_Model{

	function __construct(){
		parent:: __construct();
		$this->load->database();
	}

	function recuperarUsuarios(){
		$query = $this->db->get('usuarios');
		if ($query->num_rows()>0) {
			return $query;
		}else{
			return false;
		}
	}

}