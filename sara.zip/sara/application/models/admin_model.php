<?php

class Admin_model extends CI_Model{

	function __construct(){
		parent:: __construct();
		$this->load->database();
	}

	function agregarDatos($datos){
		$this->db->insert('aulas', array('aula'=>$datos['aula'], 'estado'=>$datos['estado']));
		$this->db->insert('cursos', array('curso'=>$datos['curso'], 'profesor'=>$datos['profesor'],
										'dia'=>$datos['dia'], 'mes'=>$datos['mes'],
										'anno'=>$datos['anno'], 'hora'=>$datos['hora']));
	}

}