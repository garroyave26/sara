<?php

class Narracion_model extends CI_Model{

	function __construct(){
		parent:: __construct();
		$this->load->database();
	}

	function agregarMensaje($datosNarracion){
		$this->db->insert('narracion', array('minuto'=>$datosNarracion['minuto'], 'mensaje'=>$datosNarracion['mensaje']));
	}

	function agregarEquipos($datos){
		$query = 'truncate equipos';
		$this->db->query($query);
		$this->db->insert('equipos', array('equipo1'=>$datos['equipo1'], 'marcador1'=>$datos['marcador1'], 'marcador2'=>$datos['marcador2'], 'equipo2'=>$datos['equipo2'] ));
	}

	function truncarTablas(){
		$query2 = 'truncate equipos';
		$this->db->query($query2);
		$query1 = 'truncate narracion';
		$this->db->query($query1);
	}
}