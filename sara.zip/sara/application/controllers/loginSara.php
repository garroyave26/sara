<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//require 'C:\Program Files (x86)\EasyPHP-DevServer-14.1VC9\data\localweb\parcial2\lib\Pusher.php';

class LoginSara extends CI_Controller {

	function __construct(){
		parent:: __construct();
		$this->load->model('loginSara_model');
	}

	function index(){
		//$data=array();
		//$contraseña = $this->cliente_model->recuperarDatos();
		//_SESSION['equipos'] = $this->cliente_model->recuperarEquipos();
		$this->load->view('login.php');
	}

	function verificacionDatos(){
		$ban=0;
		$ban1=0;
		$usuarioForm = $_POST['usuario'];
		$contrasenaForm = $_POST['contrasena'];
		$usuarios = $this->loginSara_model->recuperarUsuarios();
		foreach ($usuarios->result() as $usuario) {
			if ($usuario->usuario == $usuarioForm && $usuario->clave == $contrasenaForm) {
				$ban=1;
				if ($usuario->usuario == "admin" && $usuario->clave == "4444") {
					$ban1=2;
				}
			}else{
				
			}
		}

		if($ban == 1 && $ban1!=2){
			$this->load->view('sara.php');
		}else{
			if ($ban1 == 2) {
				$this->load->view('admin.php');
			}else{
				$this->load->view('login.php');
			}
		}
	}

}