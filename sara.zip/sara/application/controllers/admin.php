<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require 'C:\Program Files (x86)\EasyPHP-DevServer-14.1VC9\data\localweb\sara\lib\Pusher.php';

class Admin extends CI_Controller {

	function __construct(){
		parent:: __construct();
		$this->load->model('admin_model');
	}	

	function almacenarDatos(){
		$jsondata = array();
		$datos = array();

		$pusher = PusherInstance::get_pusher();
		
		$datos['aula'] = $_GET['aula'];
		//$datos['estado'] = $_GET['estado'];
		$datos['curso'] = $_GET['curso'];
		$datos['profesor'] = $_GET['profesor'];
		$datos['dia'] = $_GET['dia'];
		$datos['mes'] = $_GET['mes'];
		$datos['anno'] = $_GET['anno'];
		$datos['hora'] = $_GET['hora'];

		if($_GET['estado']== "Ocupada"){$datos['estado'] = 1;}
		if($_GET['estado']== "Reservada"){$datos['estado'] = 2;}
		if($_GET['estado']== "Libre"){$datos['estado'] = 3;}
		if($_GET['estado']== "No disponible"){$datos['estado'] = 4;}
		if($_GET['estado']== "Alerta"){$datos['estado'] = 5;}

		$this->admin_model->agregarDatos($datos);

		$pusher->trigger(
			'canal_prueba',
			'nuevo_comentario',
			array('profesor'=>$datos['profesor'], 'curso'=>$datos['curso'], 'aula'=>$datos['aula'], 'estado'=>$datos['estado'])
			);

		$jsondata['success']=$datos['aula'];

		echo json_encode($jsondata);
	}

}