<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require 'C:\Program Files (x86)\EasyPHP-DevServer-14.1VC9\data\localweb\parcial2\lib\Pusher.php';

class Cliente extends CI_Controller {

	function __construct(){
		parent:: __construct();
		$this->load->model('cliente_model');
	}

	function index(){
		$data=array();
		$_SESSION['narracion'] = $this->cliente_model->recuperarDatos();
		$_SESSION['equipos'] = $this->cliente_model->recuperarEquipos();
		$this->load->view('cliente/cliente.php', $_SESSION);
	}

}