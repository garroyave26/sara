<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require 'C:\Program Files (x86)\EasyPHP-DevServer-14.1VC9\data\localweb\parcial2\lib\Pusher.php';

class Narrador extends CI_Controller {

	function __construct(){
		parent:: __construct();
		$this->load->model('narracion_model');
	}

	function index (){
		$this->load->view('narrador/narrador.php');
	}

	function almacenarDatos(){
		$jsondata = array();
		$datosNarracion = array();
		$datosEquipos=array();

		$pusher = PusherInstance::get_pusher();

		if (isset($_GET['mensaje']) ) {
			$datosNarracion['mensaje']=$_GET['mensaje'];
			$datosNarracion['minuto']=$_GET['minuto'];
			$datosEquipos['equipo1']=$_GET['equipo1'];
			$datosEquipos['equipo2']=$_GET['equipo2'];
			$datosEquipos['marcador1']=$_GET['marcador1'];
			$datosEquipos['marcador2']=$_GET['marcador2'];
			if ($_GET['equipo1'] == "Millonarios") {
				$jsondata['success']=true;
			}else{
				$jsondata['success']=false;
			}
			
			echo json_encode($jsondata);

			$pusher->trigger(
				'canal_prueba',
				'nuevo_comentario',
				array('minuto'=>$datosNarracion['minuto'], 'mensaje'=>$datosNarracion['mensaje'], 
					'equipo1'=>$datosEquipos['equipo1'], 'equipo2'=>$datosEquipos['equipo2'],
					'marcador1'=>$datosEquipos['marcador1'], 'marcador2'=>$datosEquipos['marcador2'] )
				);

			

			$this->narracion_model->agregarMensaje($datosNarracion);
			$this->narracion_model->agregarEquipos($datosEquipos);
		}else{
			$datosNarracion['mensaje']='No esta definido';
			$datosNarracion['minuto']='No hay minutos';
		}

		echo json_encode($jsondata);

	}

	function reiniciar(){
		$jsondata=array();
		if(isset($_POST['reiniciar'])){
			$jsondata['respuesta']='si';
			$this->narracion_model->truncarTablas();
			$this->load->view('narrador/narrador.php');
		}
	}
}