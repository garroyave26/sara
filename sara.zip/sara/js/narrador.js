BASE_URL="http://localhost/parcial2";

$(document).on('ready', function(){

	var mensaje = '';


	$('#IdEnviar').on('click', function(e){
		e.preventDefault();
		mensaje = $('#idMensaje').val();
		var minuto = $('#idMinuto').val();
		var concatenacion = minuto + '´      '+ mensaje;
		$('#contenedor').before('<div align="center" class="narracion1">'+concatenacion+'</div>');
		console.log('hola mundo');

		$.ajax({
			type: 'GET',
			data: $('#formulario').serialize(),
			dataType: 'json',
			url: 'http://localhost/parcial2/narrador/almacenarDatos',
			})
			.done(function(data){
		    	if (data.success) {
		    	}else{
		    	}					
			})
			.fail(function(){
		    });

		$('#idMensaje').val('');
		$('#idMinuto').val('');    
	});	
});