BASE_URL="http://localhost/sara";

$(document).on('ready', function(){

	$('#idEnviar').on('click', function(e){
		e.preventDefault();
		
		console.log('hola mundo');

		$.ajax({
			type: 'GET',
			data: $('#formulario').serialize(),
			dataType: 'json',
			url: 'http://localhost/sara/admin/almacenarDatos',
			})
			.done(function(data){
		    	/*if (data.success) {
		    		alert('exito');
		    	}else{
		    		alert('no exito');
		    	}*/		
		    	alert("Proceso exitoso");			
			})
			.fail(function(){
				alert('Fracasó');
		    });   
	});	
});