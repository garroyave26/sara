$(document).on('ready', function(){	

	var pusher = new Pusher('6aae71182738d6023f75');
	var canal = pusher.subscribe('canal_prueba');

	canal.bind('nuevo_comentario', function(respuesta){
		//$('#id'+respuesta.aula).toggleClass('td'.respuesta.estado);
		$('#id'+respuesta.aula).text("");
		$('#id'+respuesta.aula).append(respuesta.curso);
		$('#id'+respuesta.aula).append('<br>'+respuesta.profesor);
		$('#id'+respuesta.aula).removeClass('td'+respuesta.estado);
		$('#id'+respuesta.aula).addClass('td'+respuesta.estado);
	});	
});