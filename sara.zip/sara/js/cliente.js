BASE_URL="http://localhost/parcial2";

$(document).on('ready', function(){

	var pusher = new Pusher('6aae71182738d6023f75');
	var canal = pusher.subscribe('canal_prueba');

	canal.bind('nuevo_comentario', function(respuesta){
		$('#contenedor').before('<div align="center" class="narracion1">'+respuesta.minuto+'´       '+respuesta.mensaje+'</div>');
		$('#equipo1').text(respuesta.equipo1);
		$('#equipo2').text(respuesta.equipo2);
		$('#marcador1').text(respuesta.marcador1);
		$('#marcador2').text(respuesta.marcador2);
	});	
});