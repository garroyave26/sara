<?php

#$jsondata = array();
#if (isset($_GET['equipo1'])) {
#	//print_r("hola");
#	if ($_GET['equipo1'] == "millonarios") {
#		$jsondata['success']=true;
#		//echo true;
#	}else{
#		$jsondata['success']=false;
#		//echo false;
#	} 
#	echo json_encode($jsondata);
#}

if(isset($_GET['reiniciar'])){
	echo "hola";
}